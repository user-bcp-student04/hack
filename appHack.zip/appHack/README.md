# Kipu Wallet Demo · Registro W1

Demo full-stack del flujo de registro y activación de una wallet para Perú. Incluye validación de identidad de demostración, verificación OTP simulada, creación de PIN y activación de wallet en PEN. No mueve dinero ni consulta proveedores o servicios de identidad reales.

## Ejecutar

Requiere Node.js 20 o superior.

```bash
npm install
npm run dev
```

Abre http://localhost:5173. El frontend se ejecuta en Vite y la API en http://localhost:3001. El archivo `data/wallet-demo.sqlite` se crea automáticamente. Para presentar desde otro equipo de la misma red, usa la IP LAN de la computadora anfitriona y el puerto 5173; el servidor Vite y la API escuchan en todas las interfaces. No publiques esta demo directamente en Internet.

Datos de prueba incluidos en el botón «Usar datos de prueba»: Valeria Rojas, DNI 74839216, celular 987654321 y valeria@correo.pe. El código OTP de la sesión aparece en pantalla porque la entrega SMS es simulada. Puedes usar cualquier PIN de seis dígitos y luego activar la wallet. Cada registro crea datos persistentes nuevos.

## Arquitectura

```text
Navegador (React 19 + Vite)
        │ HTTP /api, proxy de desarrollo
        ▼
API Node.js (Express 5)
  ├─ Helmet, límite de solicitudes y validación Zod
  ├─ Máquina de estados: started → verified → ready → active
  └─ SQLite (WAL, claves foráneas, restricciones únicas)
        ├─ onboarding_sessions (OTP con expiración, hash de PIN)
        ├─ users
        ├─ wallets (moneda PEN)
        └─ onboarding_events (auditoría del flujo)
```

La activación crea usuario y wallet dentro de una transacción SQLite; repetirla para la misma sesión devuelve el resultado original. El código OTP se almacena como hash con expiración de cinco minutos y máximo de cinco intentos. El PIN se deriva con scrypt y sal aleatoria; nunca se devuelve al cliente. Cada activación registra un costo atribuido de PEN 10 y fuente `demo-hackathon`, únicamente para ilustrar el reporte CAC. El navegador conserva solo el ID de sesión para recuperar un onboarding interrumpido.

Para producción, reemplazar SQLite por PostgreSQL gestionado, OTP simulado por un proveedor SMS, la captura de identidad por un KYC aprobado, y añadir autenticación de sesión, gestión de secretos, monitoreo/alertas, políticas de privacidad y revisión legal/compliance. La demo no implementa saldo real, transferencias, recuperación de PIN, antifraude ni disputa/reverso.

## API W1

| Método | Ruta | Uso |
| --- | --- | --- |
| `GET` | `/api/health` | Estado de la API |
| `POST` | `/api/onboarding` | Valida datos y crea una sesión; entrega `demoCode` solo en esta demo |
| `GET` | `/api/onboarding/:id` | Recupera estado público para reanudar el flujo |
| `POST` | `/api/onboarding/:id/resend` | Rota OTP simulado, hasta tres reenvíos por sesión |
| `POST` | `/api/onboarding/:id/verify` | Verifica OTP y avanza a `verified` |
| `POST` | `/api/onboarding/:id/security` | Guarda el hash del PIN y avanza a `ready` |
| `POST` | `/api/onboarding/:id/activate` | Crea usuario y wallet PEN; operación idempotente |
| `GET` | `/api/demo/metrics` | Sesiones, wallets activas, mediana observada, activaciones y CAC mensual simulado |

La historia no incluía un contrato técnico de endpoints; estas rutas materializan los criterios de aceptación de W1 y están implementadas en el proyecto.

## Verificación

```bash
npm test
npm run build
```

Las pruebas cubren validación, rechazo de OTP incorrecto, recorrido completo, hash del PIN, persistencia, moneda PEN, activación idempotente y reporte CAC mensual. MAU real requiere eventos de uso transaccional, que no pertenecen al alcance de esta demo W1; el endpoint reporta por separado el umbral de negocio de 1,000 a 2,000.