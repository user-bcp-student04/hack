import { useEffect, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Check,
  CheckCircle2,
  ChevronRight,
  CircleHelp,
  Clock3,
  Fingerprint,
  LockKeyhole,
  ShieldCheck,
  Smartphone,
  Sparkles,
  WalletCards,
} from 'lucide-react';
import './styles.css';

const initialProfile = { fullName: '', dni: '', phone: '', email: '' };
const steps = ['Tus datos', 'Verificación', 'Tu seguridad', 'Wallet lista'];

async function request(path, options) {
  const response = await fetch(path, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...options?.headers },
  });
  const payload = await response.json();
  if (!response.ok) throw new Error(payload.error || 'No pudimos completar la solicitud.');
  return payload;
}

function App() {
  const [profile, setProfile] = useState(initialProfile);
  const [stage, setStage] = useState(0);
  const [sessionId, setSessionId] = useState('');
  const [demoCode, setDemoCode] = useState('');
  const [phoneDisplay, setPhoneDisplay] = useState('');
  const [code, setCode] = useState('');
  const [pin, setPin] = useState('');
  const [pinAgain, setPinAgain] = useState('');
  const [walletId, setWalletId] = useState('');
  const [metrics, setMetrics] = useState({ activeWallets: 0, sessions: 0 });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    request('/api/demo/metrics').then(setMetrics).catch(() => {});
    const savedId = localStorage.getItem('kipu-onboarding-session');
    if (!savedId) return;
    request(`/api/onboarding/${savedId}`).then((session) => {
      setSessionId(session.id);
      setProfile((current) => ({ ...current, fullName: session.fullName }));
      setPhoneDisplay(session.phoneMasked);
      const stageByStatus = { started: 1, verified: 2, ready: 3, active: 3 };
      setStage(stageByStatus[session.status] ?? 0);
      if (session.status === 'active') setWalletId('active');
      if (session.status === 'started') {
        request(`/api/onboarding/${session.id}/resend`, { method: 'POST', body: '{}' })
          .then((result) => setDemoCode(result.demoCode))
          .catch((requestError) => setError(requestError.message));
      }
    }).catch(() => localStorage.removeItem('kipu-onboarding-session'));
  }, []);

  function updateProfile(event) {
    setProfile({ ...profile, [event.target.name]: event.target.value });
    if (event.target.name === 'phone') setPhoneDisplay(`+51 ••• ••• ${event.target.value.slice(-3)}`);
  }

  async function runAction(action) {
    setError('');
    setBusy(true);
    try {
      await action();
    } catch (requestError) {
      setError(requestError.message);
    } finally {
      setBusy(false);
    }
  }

  function startOnboarding(event) {
    event.preventDefault();
    runAction(async () => {
      const result = await request('/api/onboarding', { method: 'POST', body: JSON.stringify(profile) });
      setSessionId(result.sessionId);
      setDemoCode(result.demoCode);
      setPhoneDisplay(`+51 ••• ••• ${profile.phone.slice(-3)}`);
      localStorage.setItem('kipu-onboarding-session', result.sessionId);
      setStage(1);
    });
  }

  function verifyPhone(event) {
    event.preventDefault();
    runAction(async () => {
      await request(`/api/onboarding/${sessionId}/verify`, { method: 'POST', body: JSON.stringify({ code }) });
      setStage(2);
    });
  }

  function resendCode() {
    runAction(async () => {
      const result = await request(`/api/onboarding/${sessionId}/resend`, { method: 'POST', body: '{}' });
      setDemoCode(result.demoCode);
      setCode('');
    });
  }

  function configureSecurity(event) {
    event.preventDefault();
    if (pin !== pinAgain) {
      setError('Los PIN no coinciden. Intenta nuevamente.');
      return;
    }
    runAction(async () => {
      await request(`/api/onboarding/${sessionId}/security`, { method: 'POST', body: JSON.stringify({ pin }) });
      setStage(3);
    });
  }

  function activateWallet() {
    runAction(async () => {
      const result = await request(`/api/onboarding/${sessionId}/activate`, { method: 'POST', body: '{}' });
      setWalletId(result.walletId);
      localStorage.removeItem('kipu-onboarding-session');
      const latestMetrics = await request('/api/demo/metrics');
      setMetrics(latestMetrics);
    });
  }

  function resetDemo() {
    localStorage.removeItem('kipu-onboarding-session');
    setProfile(initialProfile);
    setStage(0);
    setSessionId('');
    setDemoCode('');
    setPhoneDisplay('');
    setCode('');
    setPin('');
    setPinAgain('');
    setWalletId('');
    setError('');
  }

  const complete = Boolean(walletId);

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="#inicio" aria-label="Kipu, inicio">
          <span className="brand-mark"><WalletCards size={20} strokeWidth={2.2} /></span>
          <span>Kipu<span className="brand-period">.</span></span>
        </a>
        <div className="topbar-right">
          <span className="demo-badge"><span /> DEMO PERÚ</span>
          <button className="help-button" type="button" aria-label="Ayuda" title="Ayuda"><CircleHelp size={19} /></button>
        </div>
      </header>

      <main className="page-grid" id="inicio">
        <aside className="intro-panel">
          <div className="intro-eyebrow"><span className="eyebrow-line" /> WALLET · REGISTRO W1</div>
          <h1>Tu plata,<br />más cerca<span className="headline-dot">.</span></h1>
          <p className="intro-copy">Abre tu wallet en minutos. Sin filas, sin vueltas: solo lo necesario para empezar.</p>

          <div className="trust-note">
            <div className="trust-icon"><ShieldCheck size={19} /></div>
            <div><strong>Hecha para darte confianza</strong><span>Tus datos protegidos en cada paso.</span></div>
          </div>

          <div className="aside-rule" />
          <div className="aside-metrics">
            <div className="metric-row"><span>Tiempo estimado</span><strong><Clock3 size={15} /> 3 min</strong></div>
            <div className="metric-row"><span>Wallets activadas en esta demo</span><strong>{metrics.activeWallets}</strong></div>
            <div className="metric-row"><span>CAC atribuido (simulado)</span><strong>{metrics.monthToDate?.cacPen == null ? '—' : `PEN ${metrics.monthToDate.cacPen.toFixed(2)}`}</strong></div>
          </div>
          <div className="aside-footer"><span className="secure-dot" /> Entorno seguro de demostración</div>
        </aside>

        <section className="form-panel" aria-label="Registro de wallet">
          <div className="panel-heading">
            <div>
              <div className="panel-kicker">REGISTRO DE WALLET</div>
              <h2>{complete ? 'Ya estás dentro' : stage === 0 ? 'Empecemos contigo' : steps[stage]}</h2>
            </div>
            <div className="step-count">{complete ? '4' : stage + 1}<span> / 4</span></div>
          </div>

          <div className="progress-track" aria-label={`Paso ${complete ? 4 : stage + 1} de 4`}>
            {steps.map((label, index) => (
              <div className={`progress-step ${index <= stage ? 'is-current' : ''} ${complete && index === 3 ? 'is-done' : ''}`} key={label}>
                <span className="progress-marker">{index < stage || (complete && index === 3) ? <Check size={13} /> : index + 1}</span>
                <span className="progress-label">{label}</span>
              </div>
            ))}
          </div>

          {complete ? (
            <div className="success-view">
              <div className="success-mark"><CheckCircle2 size={36} /></div>
              <div className="success-kicker">ACTIVACIÓN COMPLETADA</div>
              <h3>Tu wallet Kipu ya está lista, {profile.fullName.split(' ')[0] || 'amiga'}.</h3>
              <p>Tu cuenta en soles está activa. Ya puedes continuar al inicio y explorar tu wallet.</p>
              <div className="wallet-summary">
                <div className="summary-icon"><WalletCards size={20} /></div>
                <div><span>WALLET PERSONAL</span><strong>Saldo disponible</strong></div>
                <b>S/ 0.00</b>
              </div>
              <div className="reference-row"><span>Referencia de activación</span><code>{walletId.slice(0, 8).toUpperCase()}</code></div>
              <button className="primary-button" type="button" onClick={resetDemo}>Crear otro registro <ArrowRight size={17} /></button>
            </div>
          ) : (
            <div className="form-content">
              {stage === 0 && <>
                <p className="form-description">Solo necesitamos algunos datos para crear tu cuenta personal.</p>
                <form onSubmit={startOnboarding}>
                  <label className="field-label" htmlFor="fullName">Nombre y apellidos</label>
                  <input id="fullName" name="fullName" autoComplete="name" placeholder="Como aparece en tu DNI" value={profile.fullName} onChange={updateProfile} required minLength="4" maxLength="100" />
                  <div className="field-pair">
                    <div><label className="field-label" htmlFor="dni">DNI</label><input id="dni" name="dni" inputMode="numeric" autoComplete="off" placeholder="8 dígitos" value={profile.dni} onChange={updateProfile} required pattern="[0-9]{8}" maxLength="8" /></div>
                    <div><label className="field-label" htmlFor="phone">Celular</label><div className="phone-input"><span>+51</span><input id="phone" name="phone" type="tel" inputMode="numeric" autoComplete="tel-national" placeholder="987 654 321" value={profile.phone} onChange={updateProfile} required /></div></div>
                  </div>
                  <label className="field-label" htmlFor="email">Correo electrónico</label>
                  <input id="email" name="email" type="email" autoComplete="email" placeholder="tu@correo.com" value={profile.email} onChange={updateProfile} required maxLength="160" />
                  <button className="primary-button" type="submit" disabled={busy}>{busy ? 'Guardando...' : 'Continuar'} {!busy && <ArrowRight size={17} />}</button>
                </form>
                <button className="sample-link" type="button" onClick={() => setProfile({ fullName: 'Valeria Rojas', dni: '74839216', phone: '987654321', email: 'valeria@correo.pe' })}><Sparkles size={15} /> Usar datos de prueba</button>
              </>}

              {stage === 1 && <>
                <p className="form-description">Confirma que este celular es tuyo. Te enviamos un código de un solo uso.</p>
                <div className="destination"><div className="destination-icon"><Smartphone size={19} /></div><div><span>Enviamos el código a</span><strong>{phoneDisplay}</strong></div><button type="button" onClick={() => { setStage(0); setError(''); }} aria-label="Editar celular"><ArrowLeft size={16} /></button></div>
                <form onSubmit={verifyPhone}>
                  <label className="field-label" htmlFor="code">Código de verificación</label>
                  <input className="code-input" id="code" name="code" inputMode="numeric" autoComplete="one-time-code" placeholder="000000" value={code} onChange={(event) => setCode(event.target.value.replace(/\D/g, '').slice(0, 6))} required pattern="[0-9]{6}" />
                  {demoCode && <div className="demo-code"><span>CÓDIGO SIMULADO</span><strong>{demoCode}</strong><button type="button" onClick={() => setCode(demoCode)}>Usar código</button></div>}
                  <button className="primary-button" type="submit" disabled={busy}>{busy ? 'Verificando...' : 'Verificar celular'} {!busy && <ArrowRight size={17} />}</button>
                  <button className="sample-link" type="button" onClick={resendCode} disabled={busy}>Reenviar código de demo</button>
                </form>
              </>}

              {stage === 2 && <>
                <p className="form-description">Crea un PIN personal para proteger el acceso a tu wallet.</p>
                <div className="security-callout"><div><LockKeyhole size={17} /></div><p>Tu PIN se almacena cifrado. No lo compartas con nadie, ni con Kipu.</p></div>
                <form onSubmit={configureSecurity}>
                  <label className="field-label" htmlFor="pin">Crea tu PIN de 6 dígitos</label>
                  <input className="pin-input" id="pin" name="pin" type="password" inputMode="numeric" autoComplete="new-password" placeholder="••••••" value={pin} onChange={(event) => setPin(event.target.value.replace(/\D/g, '').slice(0, 6))} required pattern="[0-9]{6}" />
                  <label className="field-label" htmlFor="pinAgain">Confirma tu PIN</label>
                  <input className="pin-input" id="pinAgain" name="pinAgain" type="password" inputMode="numeric" autoComplete="new-password" placeholder="••••••" value={pinAgain} onChange={(event) => setPinAgain(event.target.value.replace(/\D/g, '').slice(0, 6))} required pattern="[0-9]{6}" />
                  <button className="primary-button" type="submit" disabled={busy}>{busy ? 'Protegiendo tu cuenta...' : 'Continuar'} {!busy && <ArrowRight size={17} />}</button>
                </form>
              </>}

              {stage === 3 && <>
                <div className="ready-icon"><Fingerprint size={29} /></div>
                <p className="form-description activation-copy">Un último paso y quedará activa. Al continuar, creamos tu wallet personal en soles.</p>
                <div className="activation-list">
                  <div><span><Check size={14} /></span><p><strong>Identidad registrada</strong><small>{profile.fullName}</small></p></div>
                  <div><span><Check size={14} /></span><p><strong>Celular verificado</strong><small>{phoneDisplay}</small></p></div>
                  <div><span><Check size={14} /></span><p><strong>Seguridad configurada</strong><small>PIN de acceso protegido</small></p></div>
                </div>
                <button className="primary-button" type="button" onClick={activateWallet} disabled={busy}>{busy ? 'Activando wallet...' : 'Activar mi wallet'} {!busy && <ArrowRight size={17} />}</button>
                <p className="legal-note">Al activar, aceptas los términos de uso y la política de privacidad de la demo.</p>
              </>}

              {error && <div className="error-message" role="alert">{error}</div>}
              <div className="form-footnote"><ShieldCheck size={15} /> Tus datos se usan únicamente para esta demostración.</div>
            </div>
          )}
          <div className="panel-bottom"><span>¿Ya tienes una wallet?</span><button type="button" onClick={() => setError('El acceso de usuarios existentes está fuera del alcance de esta demo.')}>Inicia sesión <ChevronRight size={15} /></button></div>
        </section>
      </main>
      <footer className="site-footer"><span>© 2026 Kipu · Demo de hackathon</span><span>Hecho para pagos cotidianos en Perú <span className="footer-sun">✳</span></span></footer>
    </div>
  );
}

export default App;