const path = require('node:path');
const fs = require('node:fs');
const { createApp } = require('./app.cjs');

const dbPath = process.env.DB_PATH || path.join(__dirname, '..', 'data', 'wallet-demo.sqlite');
fs.mkdirSync(path.dirname(dbPath), { recursive: true });
const { app } = createApp({ dbPath });
const port = Number(process.env.PORT || 3001);
app.listen(port, '0.0.0.0', () => {
  console.log(`API wallet demo disponible en http://localhost:${port}`);
});