const crypto = require('node:crypto');
const express = require('express');
const helmet = require('helmet');
const { rateLimit } = require('express-rate-limit');
const { z } = require('zod');
const Database = require('better-sqlite3');

const profileSchema = z.object({
  fullName: z.string().trim().min(4).max(100),
  dni: z.string().trim().regex(/^\d{8}$/),
  phone: z.string().trim().transform((value) => value.replace(/\D/g, '')).refine((value) => /^(51)?9\d{8}$/.test(value)),
  email: z.email().max(160).transform((value) => value.trim().toLowerCase()),
});

const verifySchema = z.object({ code: z.string().regex(/^\d{6}$/) });
const securitySchema = z.object({ pin: z.string().regex(/^\d{6}$/) });

function createDatabase(dbPath) {
  const db = new Database(dbPath);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  db.exec(`
    CREATE TABLE IF NOT EXISTS onboarding_sessions (
      id TEXT PRIMARY KEY,
      status TEXT NOT NULL CHECK(status IN ('started', 'verified', 'ready', 'active')),
      full_name TEXT NOT NULL,
      dni TEXT NOT NULL,
      phone TEXT NOT NULL,
      email TEXT NOT NULL,
      otp_hash TEXT NOT NULL,
      otp_expires_at TEXT NOT NULL,
      otp_attempts INTEGER NOT NULL DEFAULT 0,
      otp_resends INTEGER NOT NULL DEFAULT 0,
      pin_hash TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      full_name TEXT NOT NULL,
      dni TEXT NOT NULL UNIQUE,
      phone TEXT NOT NULL UNIQUE,
      email TEXT NOT NULL UNIQUE,
      created_at TEXT NOT NULL,
      acquisition_source TEXT NOT NULL DEFAULT 'demo',
      acquisition_cost_pen REAL NOT NULL DEFAULT 10.0
    );
    CREATE TABLE IF NOT EXISTS wallets (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL UNIQUE REFERENCES users(id),
      status TEXT NOT NULL CHECK(status IN ('active')),
      currency TEXT NOT NULL DEFAULT 'PEN',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS onboarding_events (
      id TEXT PRIMARY KEY,
      session_id TEXT NOT NULL REFERENCES onboarding_sessions(id),
      event_type TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
  `);
  const userColumns = new Set(db.prepare('PRAGMA table_info(users)').all().map((column) => column.name));
  if (!userColumns.has('acquisition_source')) db.exec("ALTER TABLE users ADD COLUMN acquisition_source TEXT NOT NULL DEFAULT 'demo'");
  if (!userColumns.has('acquisition_cost_pen')) db.exec('ALTER TABLE users ADD COLUMN acquisition_cost_pen REAL NOT NULL DEFAULT 10.0');
  const sessionColumns = new Set(db.prepare('PRAGMA table_info(onboarding_sessions)').all().map((column) => column.name));
  if (!sessionColumns.has('otp_resends')) db.exec('ALTER TABLE onboarding_sessions ADD COLUMN otp_resends INTEGER NOT NULL DEFAULT 0');
  return db;
}

function hashPin(pin) {
  const salt = crypto.randomBytes(16);
  const key = crypto.scryptSync(pin, salt, 64);
  return `${salt.toString('hex')}:${key.toString('hex')}`;
}

function publicSession(row) {
  return {
    id: row.id,
    status: row.status,
    fullName: row.full_name,
    phoneMasked: `+51 ••• ••• ${row.phone.slice(-3)}`,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

function createApp({ dbPath = process.env.DB_PATH || './data/wallet-demo.sqlite' } = {}) {
  const db = createDatabase(dbPath);
  const app = express();
  app.disable('x-powered-by');
  app.use(helmet());
  app.use(express.json({ limit: '10kb' }));
  app.use('/api', rateLimit({ windowMs: 15 * 60 * 1000, limit: 100, standardHeaders: 'draft-8', legacyHeaders: false }));

  app.get('/api/health', (_req, res) => res.json({ status: 'ok' }));

  app.get('/api/demo/metrics', (_req, res) => {
    const sessions = db.prepare('SELECT COUNT(*) AS total FROM onboarding_sessions').get().total;
    const active = db.prepare("SELECT COUNT(*) AS total FROM wallets WHERE status = 'active'").get().total;
    const monthly = db.prepare(`SELECT substr(created_at, 1, 7) AS month, COUNT(*) AS newUsers,
      ROUND(SUM(acquisition_cost_pen), 2) AS acquisitionSpendPen,
      ROUND(AVG(acquisition_cost_pen), 2) AS cacPen
      FROM users GROUP BY substr(created_at, 1, 7) ORDER BY month DESC LIMIT 12`).all();
    const currentMonth = new Date().toISOString().slice(0, 7);
    const thisMonth = monthly.find((row) => row.month === currentMonth);
    const durations = db.prepare(`SELECT (julianday(updated_at) - julianday(created_at)) * 1440 AS minutes
      FROM onboarding_sessions WHERE status = 'active' ORDER BY minutes`).all().map((row) => row.minutes);
    const middle = Math.floor(durations.length / 2);
    const median = durations.length === 0 ? null : durations.length % 2
      ? durations[middle]
      : (durations[middle - 1] + durations[middle]) / 2;
    res.json({
      sessions,
      activeWallets: active,
      medianOnboardingMinutes: median === null ? null : Math.round(median * 100) / 100,
      targetMinutes: 3,
      mauTarget: { min: 1000, max: 2000 },
      monthly,
      monthToDate: { newUsers: thisMonth?.newUsers ?? 0, acquisitionSpendPen: thisMonth?.acquisitionSpendPen ?? 0, cacPen: thisMonth?.cacPen ?? null },
    });
  });

  app.post('/api/onboarding', (req, res) => {
    const parsed = profileSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'Revisa los datos ingresados.', details: parsed.error.issues.map((issue) => issue.path[0]) });

    const sessionId = crypto.randomUUID();
    const now = new Date();
    const otp = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
    const otpHash = crypto.createHash('sha256').update(`${sessionId}:${otp}`).digest('hex');
    const phoneDigits = parsed.data.phone.replace(/\D/g, '').replace(/^51/, '');
    const createdAt = now.toISOString();
    db.prepare(`INSERT INTO onboarding_sessions
      (id, status, full_name, dni, phone, email, otp_hash, otp_expires_at, created_at, updated_at)
      VALUES (?, 'started', ?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(sessionId, parsed.data.fullName, parsed.data.dni, `+51${phoneDigits}`, parsed.data.email,
        otpHash, new Date(now.getTime() + 5 * 60 * 1000).toISOString(), createdAt, createdAt);
    db.prepare('INSERT INTO onboarding_events (id, session_id, event_type, created_at) VALUES (?, ?, ?, ?)')
      .run(crypto.randomUUID(), sessionId, 'onboarding.started', createdAt);

    res.status(201).json({ sessionId, status: 'started', nextStep: 'verification', demoCode: otp, expiresInSeconds: 300 });
  });

  app.get('/api/onboarding/:id', (req, res) => {
    const row = db.prepare('SELECT * FROM onboarding_sessions WHERE id = ?').get(req.params.id);
    if (!row) return res.status(404).json({ error: 'No encontramos esta sesión.' });
    res.json(publicSession(row));
  });

  app.post('/api/onboarding/:id/resend', (req, res) => {
    const row = db.prepare('SELECT * FROM onboarding_sessions WHERE id = ?').get(req.params.id);
    if (!row) return res.status(404).json({ error: 'No encontramos esta sesión.' });
    if (row.status !== 'started') return res.status(409).json({ error: 'La verificación ya fue completada.' });
    if (row.otp_resends >= 3) return res.status(429).json({ error: 'Alcanzaste el máximo de reenvíos.' });
    const otp = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
    const otpHash = crypto.createHash('sha256').update(`${row.id}:${otp}`).digest('hex');
    const now = new Date();
    db.prepare(`UPDATE onboarding_sessions SET otp_hash = ?, otp_expires_at = ?, otp_attempts = 0,
      otp_resends = otp_resends + 1, updated_at = ? WHERE id = ?`)
      .run(otpHash, new Date(now.getTime() + 5 * 60 * 1000).toISOString(), now.toISOString(), row.id);
    db.prepare('INSERT INTO onboarding_events (id, session_id, event_type, created_at) VALUES (?, ?, ?, ?)')
      .run(crypto.randomUUID(), row.id, 'onboarding.otp_resent', now.toISOString());
    res.json({ demoCode: otp, expiresInSeconds: 300 });
  });

  app.post('/api/onboarding/:id/verify', (req, res) => {
    const parsed = verifySchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'Ingresa el código de 6 dígitos.' });
    const row = db.prepare('SELECT * FROM onboarding_sessions WHERE id = ?').get(req.params.id);
    if (!row) return res.status(404).json({ error: 'No encontramos esta sesión.' });
    if (row.status !== 'started') return res.status(409).json({ error: 'La verificación ya fue completada.' });
    if (row.otp_attempts >= 5) return res.status(429).json({ error: 'Alcanzaste el máximo de intentos. Inicia un nuevo registro.' });
    if (Date.now() > Date.parse(row.otp_expires_at)) return res.status(410).json({ error: 'El código venció. Inicia un nuevo registro.' });

    const suppliedHash = crypto.createHash('sha256').update(`${row.id}:${parsed.data.code}`).digest();
    const expectedHash = Buffer.from(row.otp_hash, 'hex');
    db.prepare('UPDATE onboarding_sessions SET otp_attempts = otp_attempts + 1, updated_at = ? WHERE id = ?').run(new Date().toISOString(), row.id);
    if (!crypto.timingSafeEqual(suppliedHash, expectedHash)) return res.status(400).json({ error: 'El código no coincide. Revisa e intenta otra vez.' });

    const now = new Date().toISOString();
    db.prepare("UPDATE onboarding_sessions SET status = 'verified', otp_hash = '', updated_at = ? WHERE id = ?").run(now, row.id);
    db.prepare('INSERT INTO onboarding_events (id, session_id, event_type, created_at) VALUES (?, ?, ?, ?)')
      .run(crypto.randomUUID(), row.id, 'onboarding.phone_verified', now);
    res.json({ status: 'verified', nextStep: 'security' });
  });

  app.post('/api/onboarding/:id/security', (req, res) => {
    const parsed = securitySchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'El PIN debe tener 6 dígitos.' });
    const row = db.prepare('SELECT * FROM onboarding_sessions WHERE id = ?').get(req.params.id);
    if (!row) return res.status(404).json({ error: 'No encontramos esta sesión.' });
    if (row.status !== 'verified') return res.status(409).json({ error: 'Completa primero la verificación.' });
    const now = new Date().toISOString();
    db.prepare("UPDATE onboarding_sessions SET status = 'ready', pin_hash = ?, updated_at = ? WHERE id = ?")
      .run(hashPin(parsed.data.pin), now, row.id);
    db.prepare('INSERT INTO onboarding_events (id, session_id, event_type, created_at) VALUES (?, ?, ?, ?)')
      .run(crypto.randomUUID(), row.id, 'onboarding.security_configured', now);
    res.json({ status: 'ready', nextStep: 'activation' });
  });

  app.post('/api/onboarding/:id/activate', (req, res) => {
    const row = db.prepare('SELECT * FROM onboarding_sessions WHERE id = ?').get(req.params.id);
    if (!row) return res.status(404).json({ error: 'No encontramos esta sesión.' });
    if (row.status === 'active') {
      const existing = db.prepare('SELECT wallets.id AS wallet_id FROM users JOIN wallets ON wallets.user_id = users.id WHERE users.dni = ?').get(row.dni);
      return res.json({ status: 'active', walletId: existing.wallet_id, idempotent: true });
    }
    if (row.status !== 'ready') return res.status(409).json({ error: 'Completa los pasos pendientes antes de activar.' });

    const now = new Date().toISOString();
    const userId = crypto.randomUUID();
    const walletId = crypto.randomUUID();
    const activate = db.transaction(() => {
      db.prepare(`INSERT INTO users
        (id, full_name, dni, phone, email, created_at, acquisition_source, acquisition_cost_pen)
        VALUES (?, ?, ?, ?, ?, ?, 'demo-hackathon', 10.0)`)
        .run(userId, row.full_name, row.dni, row.phone, row.email, now);
      db.prepare("INSERT INTO wallets (id, user_id, status, currency, created_at) VALUES (?, ?, 'active', 'PEN', ?)")
        .run(walletId, userId, now);
      db.prepare("UPDATE onboarding_sessions SET status = 'active', updated_at = ? WHERE id = ?").run(now, row.id);
      db.prepare('INSERT INTO onboarding_events (id, session_id, event_type, created_at) VALUES (?, ?, ?, ?)')
        .run(crypto.randomUUID(), row.id, 'wallet.activated', now);
    });

    try {
      activate();
    } catch (error) {
      if (error.code === 'SQLITE_CONSTRAINT_UNIQUE') return res.status(409).json({ error: 'Ya existe una cuenta con este DNI, celular o correo.' });
      throw error;
    }
    res.status(201).json({ status: 'active', walletId, currency: 'PEN', idempotent: false });
  });

  app.use((error, _req, res, _next) => {
    console.error(error);
    res.status(500).json({ error: 'Ocurrió un error inesperado. Intenta nuevamente.' });
  });

  return { app, db };
}

module.exports = { createApp };