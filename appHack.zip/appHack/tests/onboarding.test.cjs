const { test } = require('node:test');
const assert = require('node:assert/strict');
const { createApp } = require('../server/app.cjs');

async function withApi(run) {
  const { app, db } = createApp({ dbPath: ':memory:' });
  const server = app.listen(0, '127.0.0.1');
  await new Promise((resolve) => server.once('listening', resolve));
  const baseUrl = `http://127.0.0.1:${server.address().port}`;
  try {
    await run(baseUrl, db);
  } finally {
    await new Promise((resolve) => server.close(resolve));
    db.close();
  }
}

const profile = {
  fullName: 'Valeria Rojas',
  dni: '74839216',
  phone: '987654321',
  email: 'valeria@correo.pe',
};

test('rechaza datos inválidos sin crear una sesión', async () => {
  await withApi(async (baseUrl, db) => {
    const response = await fetch(`${baseUrl}/api/onboarding`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ ...profile, dni: '123' }),
    });
    assert.equal(response.status, 400);
    assert.equal(db.prepare('SELECT COUNT(*) AS count FROM onboarding_sessions').get().count, 0);
  });
});

test('completa onboarding, activa una wallet PEN e impide duplicar la activación', async () => {
  await withApi(async (baseUrl, db) => {
    const startResponse = await fetch(`${baseUrl}/api/onboarding`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(profile),
    });
    assert.equal(startResponse.status, 201);
    const start = await startResponse.json();
    assert.equal(start.status, 'started');

    const resendResponse = await fetch(`${baseUrl}/api/onboarding/${start.sessionId}/resend`, { method: 'POST' });
    assert.equal(resendResponse.status, 200);
    const resent = await resendResponse.json();

    const wrongCode = await fetch(`${baseUrl}/api/onboarding/${start.sessionId}/verify`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ code: resent.demoCode === '000000' ? '000001' : '000000' }),
    });
    assert.equal(wrongCode.status, 400);

    const verifiedResponse = await fetch(`${baseUrl}/api/onboarding/${start.sessionId}/verify`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ code: resent.demoCode }),
    });
    assert.equal(verifiedResponse.status, 200);
    assert.equal((await verifiedResponse.json()).status, 'verified');

    const securityResponse = await fetch(`${baseUrl}/api/onboarding/${start.sessionId}/security`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ pin: '482916' }),
    });
    assert.equal(securityResponse.status, 200);
    assert.equal((await securityResponse.json()).status, 'ready');
    const pinHash = db.prepare('SELECT pin_hash FROM onboarding_sessions WHERE id = ?').get(start.sessionId).pin_hash;
    assert.notEqual(pinHash, '482916');
    assert.match(pinHash, /^[a-f0-9]+:[a-f0-9]+$/);

    const activateResponse = await fetch(`${baseUrl}/api/onboarding/${start.sessionId}/activate`, { method: 'POST' });
    assert.equal(activateResponse.status, 201);
    const activated = await activateResponse.json();
    assert.equal(activated.status, 'active');
    assert.equal(activated.currency, 'PEN');

    const repeatedResponse = await fetch(`${baseUrl}/api/onboarding/${start.sessionId}/activate`, { method: 'POST' });
    assert.equal(repeatedResponse.status, 200);
    assert.equal((await repeatedResponse.json()).idempotent, true);
    assert.equal(db.prepare('SELECT COUNT(*) AS count FROM users').get().count, 1);
    assert.equal(db.prepare('SELECT COUNT(*) AS count FROM wallets').get().count, 1);
    assert.equal(db.prepare('SELECT COUNT(*) AS count FROM onboarding_events').get().count, 5);

    const metricsResponse = await fetch(`${baseUrl}/api/demo/metrics`);
    const metrics = await metricsResponse.json();
    assert.equal(metrics.activeWallets, 1);
    assert.equal(metrics.monthToDate.newUsers, 1);
    assert.equal(metrics.monthToDate.acquisitionSpendPen, 10);
    assert.equal(metrics.monthToDate.cacPen, 10);
    assert.deepEqual(metrics.mauTarget, { min: 1000, max: 2000 });
  });
});